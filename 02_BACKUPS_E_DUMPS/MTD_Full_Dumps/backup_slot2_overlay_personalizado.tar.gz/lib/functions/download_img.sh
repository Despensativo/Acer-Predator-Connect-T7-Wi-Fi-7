#!/bin/sh

logger download_img - enter

net_status=$(nvram get main_status)
if [ "$net_status" != "connected" ]; then
    logger download_img - network disconnected
    exit 1
fi

is_download_img=""
is_download_img=$(ps | grep 'fota ipq' | grep -v grep | awk '{print $1}')
if [ "$is_download_img" != "" ];then
    logger download_img - ipq ota in progress
    exit 2
fi

nvram set fota_update ''
nvram set fota_force ''
nvram set fota_version ''

fota ipq check_version

fota_update=$(nvram get fota_update)
fota_force=$(nvram get fota_force)
fota_version=$(nvram get fota_version)
fota_force_version=$(nvram get fota_force_version)

if [ "$fota_update" == "1" -a "$fota_force" == "1" -a "$fota_version" != "$fota_force_version" ]; then
    nvram set fota_force_ready ''
    nvram set fota_progress ''
    fota ipq download

    fota_progress=$(nvram get fota_progress)
    if [ "$fota_progress" == "100.0%" ]; then
        nvram set fota_force_version $fota_version
        nvram set fota_force_ready 1
        logger download_img - download success
    else
        logger download_img - download fail fota_progress:$fota_progress
    fi
else
    logger download_img - check version fail fota_update:$fota_update fota_force:$fota_force
    logger download_img - check version fail fota_force_version:$fota_force_version fota_version:$fota_version
fi


