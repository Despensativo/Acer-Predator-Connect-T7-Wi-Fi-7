#!/bin/sh

if [[ "$(uptime)" != *"day"* ]]; then
    logger silent reboot - not yet to day
    exit 3
fi

days=$(uptime | sed 's/^.*up //' | sed 's/[[:space:]].*$//')
if [ "${days}" -lt 7 ];then
    logger silent reboot - not yet to week
    exit 1
fi

network_mode=$(nvram get network_mode_for_silent)
default_flow_limit=5242880

if [ "$network_mode" != "6" ];then
    network_dev=$(route -n | grep -w 'UG' | grep -o '[^ ]*$' | head -n 1)
else
    network_dev=$(nvram get mesh_agent_interface)
    if [[ $network_dev == ath* ]];then
        network_dev="br-lan"
    fi
    dev_count=$(cat /tmp/.mesh_node_all | wc -l)
    default_flow_limit=`expr $default_flow_limit \* $dev_count`
fi


rx=$(ifconfig $network_dev | grep 'byte' | sed 's/^.*RX[[:space:]]bytes://' | sed 's/[[:space:]].*$//')
tx=$(ifconfig $network_dev | grep 'byte' | sed 's/^.*TX[[:space:]]bytes://' | sed 's/[[:space:]].*$//')
total=$((rx+tx))

sleep 600

rx=$(ifconfig $network_dev | grep 'byte' | sed 's/^.*RX[[:space:]]bytes://' | sed 's/[[:space:]].*$//')
tx=$(ifconfig $network_dev | grep 'byte' | sed 's/^.*TX[[:space:]]bytes://' | sed 's/[[:space:]].*$//')
increment=$((rx+tx-total))


if [ "${increment}" -gt $default_flow_limit ];then
    logger silent reboot - network in use
    exit 2
fi

# file_path="/tmp/nand-4k-ipq5332-single.img"
# force_ota_flag=$(nvram get fota_force_ready)

# if [ -f "$file_path" -a  "$force_ota_flag" == "1" ]; then
#     sysupgrade $file_path
# else
reboot
# fi
