#!/bin/sh

logger update_img - enter

file_path="/tmp/nand-4k-ipq5332-single.img"
force_ota_flag=$(nvram get fota_force_ready)

if [ -f "$file_path" -a  "$force_ota_flag" == "1" ]; then
    fota ipq install
else
    logger update_img - fail force_ota_flag:$force_ota_flag
fi